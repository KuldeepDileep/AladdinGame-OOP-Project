#ifndef PLACEOBJECTS_H
#define PLACEOBJECTS_H
#include "PlatformStairs.h"
#include "Unit.h"
#include "CollisionCheck.h"
#include "Angaray.h"
#include "Aladdin.h"
#pragma once
class PlaceObjects: public Unit
{
    public:
        PlaceObjects(LTexture* image);
        virtual ~PlaceObjects();
        void LoadStairs();
        void LoadPlatforms();
        void LoadPillars();
        void RenderStairs(SDL_Renderer* gRenderer, float cameraXX, float cameraYY);
        void RenderPillars(SDL_Renderer* gRenderer, float cameraXX, float cameraYY);
        void RenderPlatforms(SDL_Renderer* gRenderer, float cameraXX, float cameraYY);
        void StairAladdinCollision(Unit* aladdin);

    private:
        //float cameraX;
        //float cameraY;
        //PlatformsNStairs* s1;
        PlatformsNStairs* stairs;
        PlatformsNStairs* platforms;
        PlatformsNStairs* pillar;
        LTexture* gBackgroundObjects;


};

#endif // PLACEOBJECTS_H
