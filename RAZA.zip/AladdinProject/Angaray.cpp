#include "Angaray.h"

Angaray::Angaray()
{
    //ctor
}

Angaray::~Angaray()
{
    //dtor
}
void Angaray::Clip(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;

    spriteClips[ 0 ].x = 0;
    spriteClips[ 0 ].y = 0;
    spriteClips[ 0 ].w = 149;
    spriteClips[ 0 ].h = 42;



    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

}
