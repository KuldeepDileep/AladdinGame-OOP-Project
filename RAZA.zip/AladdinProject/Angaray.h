#include "Unit.h"
#pragma once

class Angaray:public Unit
{
public:
    Angaray();
    virtual ~Angaray();
    void Clip(LTexture* image, float x, float y);
    void AngarayCollision(Unit* aladdin);
private:
    SDL_Rect spriteClips[ 1 ];




};

