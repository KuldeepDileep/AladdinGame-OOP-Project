#ifndef COLLISIONCHECK_H
#define COLLISIONCHECK_H
#include <iostream>
using namespace std;
template <class T1, class T2>
class CollisionCheck
{
    public:
        CollisionCheck();
        virtual ~CollisionCheck();
        bool Collision(T1*, T2*);
};

template <class T1, class T2>
CollisionCheck<T1, T2>::CollisionCheck()
{

}
template <class T1, class T2>
CollisionCheck<T1, T2>::~CollisionCheck()
{

}
template <class T1, class T2>
bool CollisionCheck<T1, T2>::Collision(T1* obj1, T2* obj2)
{
    //The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect aladdinObj
    leftA = obj1->GetX();
    rightA = obj1->GetX() + obj1->GetWidth();
    topA = obj1->GetY();
    bottomA = obj1->GetY() + obj1->GetHeight();

    //Calculate the sides of rect knifeObj
    leftB = obj2->GetX();
    rightB = obj2->GetX() + obj2->GetWidth();
    topB = obj2->GetY();
    bottomB = obj2->GetY() + obj2->GetHeight();

    if( bottomA <= topB )
    {
        return false;
    }

    if( topA >= bottomB )
    {
        return false;
    }

    if( rightA <= leftB )
    {
        return false;
    }

    if( leftA >= rightB )
    {
        return false;
    }

    //If none of the sides from A are outside B
    return true;
}

#endif // COLLISIONCHECK_H
