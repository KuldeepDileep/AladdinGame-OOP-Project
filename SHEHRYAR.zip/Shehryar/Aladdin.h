#ifndef ALADDIN_H
#define ALADDIN_H
#include "Unit.h"
#include "Sprite.h"
#include <iostream>
enum ANIMATION {IDLE1, RUN, ATTACK, THROW, VERTICAL_J, ROPE};
static int CURRENT_DIRECTION = RIGHT;
static int Gravity = -3;

class Aladdin : public Unit
{
    public:
        Aladdin();
        Aladdin(SDL_Renderer* gRenderer);
        void knifeAttack(long int& frame, SDL_Renderer* gRenderer);
        void appleThrow();
        void idleAnimation1();
        void set_animation(int animation);

        int negativeFrame;


        void Clip(LTexture* image, float x, float y);
        void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
        int getPosy();
        int getGroundx();
        void Move(int direction);
    protected:

    private:
        const static int IDLE1_FRAMES = 1;

        const static int RUN_FRAMES = 12;
        const static int ATTACK_FRAMES = 5;
        const static int THROW_FRAMES = 6;
        const static int VERTICAL_JFRAMES = 12;
        const static int ROPE_FRAMES = 10;

        int CURRENT_ANIMATION = IDLE1;
        Sprite* IDLE1_CLIPS [IDLE1_FRAMES];
        Sprite* RUN_CLIPS [RUN_FRAMES];
        Sprite* THROW_CLIPS [THROW_FRAMES];
        Sprite* ATTACK_CLIPS [ATTACK_FRAMES];
        Sprite* ROPE_CLIPS[ROPE_FRAMES];
        Sprite* VERTICAL_JCLIPS [VERTICAL_JFRAMES];
        bool canThrowApple;
        bool is_attack = false;
        bool is_jump = false;
        bool is_throw = false;
        void Jump(int clip);
        void manageEvents(long int& frame, Sprite**& currentani, int& currentframes, int& buffer, SDL_RendererFlip& flip);
        //int frame = 0;
//        Projectile* project;
        int powerdup;

};

#endif // ALADDIN_H
