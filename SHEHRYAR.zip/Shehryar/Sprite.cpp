
#include "Sprite.h"

Sprite::Sprite()
{
    //ctor
}

Sprite::~Sprite()
{
    //dtor
    delete spriteClip;
    delete hitBox;
    delete hurtBox;
}

Sprite::Sprite(LTexture* image, int rectx, int recty, int rectw, int recth, int anchorx, int anchory, int hitx, int hity, int hitw, int hith, int hurtx, int hurty, int hurtw, int hurth )
{
    spriteSheetTexture = image;
    spriteClip = new SDL_Rect;
    spriteClip->x = rectx;
    spriteClip->y = recty;
    spriteClip->h = recth;
    spriteClip->w = rectw;

    hitBox = new SDL_Rect;
    hitBox->x = hitx;
    hitBox->y = hity;
    hitBox->w = hitw;
    hitBox->h = hith;

    hurtBox = new SDL_Rect;
    hurtBox->x = hurtx;
    hurtBox->y = hurty;
    hurtBox->w = hurtw;
    hurtBox->h = hurth;

    AnchorX = anchorx - rectx;
    AnchorY = anchory - recty;
}

void Sprite::Render(int posx, int posy, SDL_RendererFlip flip, SDL_Renderer* gRenderer)
{
    if (flip == SDL_FLIP_NONE)
    {
        spriteSheetTexture->Render(posx - AnchorX, posy - AnchorY, spriteClip, 0.0, NULL, flip, gRenderer);

    }
    else
    {
        int tempanchx = spriteClip->w - AnchorX;
        spriteSheetTexture->Render(posx - tempanchx , posy - AnchorY, spriteClip, 0.0, NULL, flip, gRenderer);

    }
}

int Sprite::get_width()
{
    return spriteClip->w;
}
int Sprite::get_height()
{
    return spriteClip->h;
}
