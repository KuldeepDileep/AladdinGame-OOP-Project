#include "Aladdin.h"

Aladdin::Aladdin()
{
    spriteSheetTexture = NULL;

}
Aladdin::Aladdin(SDL_Renderer* gRenderer)
{

}
void Aladdin::Clip(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;
    negativeFrame = 0;
    IDLE1_CLIPS[0] = new Sprite(image, 0, 0, 41, 59, 3, 58,0, 0, 41, 59, 0, 0, 0, 0);



    RUN_CLIPS[0] = new Sprite(image, 14, 1224, 50, 50, 16, 1273, 14, 1224, 50, 50, 0, 0, 0, 0);
    RUN_CLIPS[1] = new Sprite(image, 66, 1221, 43, 53, 68, 1273, 66, 1221, 43, 53, 0, 0, 0, 0);
    RUN_CLIPS[2] = new Sprite(image, 120, 1220, 41, 53, 122, 1273, 120, 1220, 41, 53, 0, 0, 0, 0);
    RUN_CLIPS[2] = new Sprite(image, 170, 1215, 42, 58, 172, 1273, 170, 1215, 42, 58, 0, 0, 0, 0);
    RUN_CLIPS[3] = new Sprite(image, 220, 1216, 52, 57, 222, 1273, 220, 1216, 52,57, 0, 0, 0, 0);
    RUN_CLIPS[4] = new Sprite(image, 279, 1218, 46, 55, 281, 1273, 279, 1218, 46, 55, 0, 0, 0, 0);
    RUN_CLIPS[5] = new Sprite(image, 334, 1214, 42, 59, 336, 1273, 334, 1214, 42, 59, 0, 0, 0, 0);
    RUN_CLIPS[6] = new Sprite(image, 386, 1220, 41, 53, 388, 1273, 386, 1220, 41, 53, 0, 0, 0, 0);
    RUN_CLIPS[7] = new Sprite(image, 440, 1218, 35, 55, 442, 1273, 440, 1218, 35, 55, 0, 0, 0, 0);
    RUN_CLIPS[8] = new Sprite(image, 488, 1215, 49, 58, 490, 1273, 488, 1215, 49, 58, 0, 0, 0, 0);
    RUN_CLIPS[9] = new Sprite(image, 547, 1214, 55, 59, 549, 1273, 547, 1214, 55, 59, 0, 0, 0, 0);
    RUN_CLIPS[10] = new Sprite(image, 611, 1218, 55, 56, 613, 1273, 611, 1218, 55, 56, 0, 0, 0, 0);
    RUN_CLIPS[11] = new Sprite(image, 678, 1217, 45, 58, 680, 1273, 678, 1217, 45, 58, 0, 0, 0, 0);


    VERTICAL_JCLIPS[0] = new Sprite(image, 7, 845, 60, 44, 22, 884, 7, 845, 60, 44, 0, 0, 0, 0);
    VERTICAL_JCLIPS[1] = new Sprite(image, 74, 827, 53, 63, 99, 884, 74, 827, 53, 63, 0, 0, 0, 0);
    VERTICAL_JCLIPS[2] = new Sprite(image, 137, 829, 54, 61, 152, 884, 137, 829, 54, 61, 0, 0, 0, 0);
    VERTICAL_JCLIPS[3] = new Sprite(image, 203, 823, 54, 70, 218, 884, 203, 823, 54, 70, 0, 0, 0, 0);
    VERTICAL_JCLIPS[4] = new Sprite(image, 268, 819, 52, 75, 283, 884, 268, 819, 52, 75, 0, 0, 0, 0);
    VERTICAL_JCLIPS[5] = new Sprite(image, 335, 828, 39, 67, 350, 884, 335, 828, 39, 67, 0, 0, 0, 0);
    VERTICAL_JCLIPS[6] = new Sprite(image, 390, 818, 35, 79, 405, 884, 390, 818, 35, 79, 0, 0, 0, 0);
    VERTICAL_JCLIPS[7] = new Sprite(image, 448, 808, 34, 93, 463, 884, 448, 808, 34, 93, 0, 0, 0, 0);
    VERTICAL_JCLIPS[8] = new Sprite(image, 504, 810, 34, 93, 519, 884, 504, 810, 34, 93, 0, 0, 0, 0);
    VERTICAL_JCLIPS[9] = new Sprite(image, 564, 812, 34, 93, 579, 884, 564, 812, 34, 93, 0, 0, 0, 0);
    VERTICAL_JCLIPS[10] = new Sprite(image, 14, 900, 55, 84, 29, 978, 14, 900, 55, 84, 0, 0, 0, 0);
    VERTICAL_JCLIPS[11] = new Sprite(image, 86, 911, 55, 65, 101, 970, 86, 911, 55, 65, 0, 0, 0, 0);

    ATTACK_CLIPS[0] = new Sprite(image, 5, 335, 46, 53, 14, 388, 5, 335, 46, 53, 0, 0, 0, 0);
    ATTACK_CLIPS[1] = new Sprite(image, 54, 325, 52, 63, 64, 387, 54, 325, 52, 63, 0, 0, 0, 0);
    ATTACK_CLIPS[2] = new Sprite(image, 115, 314, 45, 74, 119, 388,115, 314, 45, 74, 0, 0, 0, 0);
    ATTACK_CLIPS[3] = new Sprite(image, 171, 318, 82, 70, 171, 388, 171, 337, 40, 51 ,199, 318 , 54, 63);
    ATTACK_CLIPS[4] = new Sprite(image, 260, 335, 51, 53, 267, 388, 260, 335, 51, 53, 0, 0, 0, 0);

    THROW_CLIPS[0] = new Sprite(image, 7, 235, 43, 56, 7, 291, 7, 235, 43, 56, 0, 0, 0, 0);
    THROW_CLIPS[1] = new Sprite(image, 57, 232, 41, 59, 57, 291, 57, 232, 41, 59, 0, 0, 0, 0);
    THROW_CLIPS[2] = new Sprite(image, 109, 233, 38, 58, 109, 291, 109, 233, 38, 58, 0, 0, 0, 0);
    THROW_CLIPS[3] = new Sprite(image, 163, 231, 46, 60, 164, 291, 163, 231, 46, 60, 0, 0, 0, 0);
    THROW_CLIPS[4] = new Sprite(image, 221, 233, 37, 58, 221, 291, 221, 233, 37, 58, 0, 0, 0, 0);
    THROW_CLIPS[5] = new Sprite(image, 268, 239, 39, 52, 269, 291, 268, 239, 39, 52, 0, 0, 0, 0);

    ROPE_CLIPS[0] = new Sprite(image, 11, 1362, 29, 86, 27, 1384, 11, 1362, 29, 86, 0, 0, 0, 0);
    ROPE_CLIPS[1] = new Sprite(image, 53, 1361, 28, 89, 67, 1383, 53, 1361, 28, 89, 0, 0, 0, 0);
//    ROPE_CLIPS[2] = new Sprite(image, )

    this->x = x;
    this->y = y;


    //friction = 0.95f;
    speedx = 0;
    speedy = 0;
    alive  = true;
}
void Aladdin::set_animation(int animation)
{
    CURRENT_ANIMATION = animation;
}
void Aladdin::knifeAttack(long int& frame, SDL_Renderer* gRenderer)
{

}
void Aladdin::appleThrow()
{

}
void Aladdin::manageEvents(long int& frame, Sprite**& currentani, int& currentframes, int& buffer, SDL_RendererFlip& flip)
{
    if (CURRENT_DIRECTION == RIGHT)
        flip = SDL_FLIP_NONE;
    else
        flip = SDL_FLIP_HORIZONTAL;
    if (negativeFrame == 0)
    {

        if (CURRENT_ANIMATION == IDLE1)
        {
            is_jump = false;
            is_attack = false;
            currentani = IDLE1_CLIPS;
            currentframes = IDLE1_FRAMES;
        }

        if (CURRENT_ANIMATION == RUN)
        {
            is_jump = false;
            is_attack = false;
            is_throw = false;
            currentani = RUN_CLIPS;
            currentframes = RUN_FRAMES;
        }
        if (CURRENT_ANIMATION == ATTACK)
        {
            frame = 0;
            is_attack = true;
            is_jump = false;
            is_throw = false;
            negativeFrame = buffer*ATTACK_FRAMES;
            currentani = ATTACK_CLIPS;
            currentframes = ATTACK_FRAMES;
       }
       if (CURRENT_ANIMATION == THROW)
       {
           frame = 0;
           is_throw = true;
           is_attack = false;
           is_jump = false;
           negativeFrame = buffer*THROW_FRAMES;
           currentani = THROW_CLIPS;
           currentframes = THROW_FRAMES;
       }

       if (CURRENT_ANIMATION == VERTICAL_J)
        {
            frame = 0;
            is_jump = true;
            is_attack = false;
            is_throw = false;
            negativeFrame = buffer*VERTICAL_JFRAMES;
            currentani = VERTICAL_JCLIPS;
            currentframes = VERTICAL_JFRAMES;
        }

    }
    else
    {
        negativeFrame--;
        if (is_jump)
        {
            currentani = VERTICAL_JCLIPS;
            currentframes = VERTICAL_JFRAMES;
            Jump((frame/buffer) % (currentframes));
        }
        if (is_attack)
        {
            currentani = ATTACK_CLIPS;
            currentframes = ATTACK_FRAMES;
        }
        if (is_throw)
        {
            currentani = THROW_CLIPS;
            currentframes = THROW_FRAMES;
        }
    }

}
int prev_clip = -1;
bool mid = false;
void Aladdin::Jump(int clip)
{
//    if (clip <6)
//    {
//        y+=Gravity;
//        if (clip - prev_clip == 2)
//        {
//            std::cout<<"HERE"<<std::endl;
//            prev_clip = clip;
//            Gravity++;
//
//        }
//    }
//    else if (clip == 6)
//    {
//        prev_clip = clip;
//
//        if (!mid)
//        {
//                std::cout<<"HERE6"<<std::endl;
//            mid = true;
////            Gravity--;
//        }
//
//    }
//    else if (clip > 6)
//    {
//        y-=Gravity;
//
//        if (clip - prev_clip == 2)
//        {
//                        std::cout<<"HERE2"<<std::endl;
//
//            prev_clip = clip;
//            Gravity--;
//        }
//    }
//    if (clip - prev_clip == -10 )
//    {
//        y-=Gravity;
//        mid = false;
//        prev_clip = -1;
//    }
    if (clip<6)
    {
        y+=Gravity;
    }
    else
    {
        y-=Gravity;
    }
    std::cout<<Gravity<<"KKKKK"<<clip-prev_clip<<"LLLL"<<prev_clip<<endl;

}
void Aladdin::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    Sprite** currentani;
    int currentframes;
    int buffer = 6;
    SDL_RendererFlip flip;
    manageEvents(frame, currentani, currentframes, buffer, flip);
    //std::cout<<(frame/buffer) % currentframes<<std::endl;
    currentani[(frame/buffer) % currentframes]->Render(x, y , flip, gRenderer);
    set_animation(IDLE1);
}
//int Aladdin::getPosx()
//{
//
//}
//int Aladdin::getPosy()
//{
//
//}
//int Aladdin::getGroundx()
//{
//
//}
void Aladdin::Move(int direction)
{
//    is_run = false;
    if (negativeFrame == 0)
    {
        if(direction==LEFT)
        {
            speedx = -5;
            x+=speedx;
            CURRENT_DIRECTION = LEFT;
            set_animation(RUN);

        }

        if(direction==RIGHT)
        {
            speedx = 5;
            x+=speedx;
            CURRENT_DIRECTION = RIGHT;
            set_animation(RUN);

        }

        if(direction==UP)
        {
            speedy = 0;
            y+=speedy;
            CURRENT_ANIMATION = VERTICAL_J;
        }

        if(direction==DOWN)
        {
            speedy = 0;
            y+=speedy;
        }
    }
    else
    {
        if (is_jump && !is_attack)
        {

            if(direction==LEFT)
            {
                speedx = -3;
                x+=speedx;
                CURRENT_DIRECTION = LEFT;

            }

            if(direction==RIGHT)
            {
                speedx = 3;
                x+=speedx;
                CURRENT_DIRECTION = RIGHT;
            }
        }
    }

}
