#include "Unit.h"

Unit::Unit()
{

}
//
//Unit::Unit(LTexture* image, float x, float y)
//{
//
//}


Unit::~Unit()
{

}

void Unit::SetAlive(bool alive)
{
    //this->alive = alive;
}

bool Unit::GetAlive()
{
    return alive;
}

void Unit::set_animation(int direction)
{

}

void Unit::Move(int direction)
{

}
void Unit::Clip(LTexture* image, float x, float y)
{

}
void Unit::Move()
{
//     speedx = speedx * friction;
//     speedy = speedy * friction;
//
//     x = x + speedx;
//     y = y + speedy;
}

void Unit::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{


}

int Unit::GetWidth()
{
    return width;
}

int Unit::GetHeight()
{
    return height;
}

float Unit::GetX()
{
    return x;
}
float Unit::GetY()
{
    return y;
}
