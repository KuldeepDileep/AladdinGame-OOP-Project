#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"

using namespace std;


enum MOTION {RIGHT, LEFT, UP, DOWN};

class Unit
{
    protected:


    public:
        bool alive;
        float x;
        float y;
        float speedx;
        float speedy;
        int width;
        int height;
        //float friction; //lower speed means more friction
        LTexture* spriteSheetTexture;
        void virtual Clip(LTexture* image, float x, float y);
        Unit();
        virtual ~Unit();
        void SetAlive(bool);
        bool GetAlive();
        int GetWidth();
        int GetHeight();
        float GetX();
        float GetY();
        void virtual set_animation(int animation);
        void virtual Move(int direction);
        void virtual Move();
        void virtual Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};



