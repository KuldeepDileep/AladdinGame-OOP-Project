#pragma once
#ifndef SPRITE_H
#define SPRITE_H
#include "SDL.h"
#include "LTexture.h"



class Sprite
{
    public:
        Sprite();
        virtual ~Sprite();
        Sprite(LTexture* image,
                int rectx, int recty,
                 int rectw, int recth, int anchorx,
                  int anchory, int hitx, int hity, int hitw,
                   int hith, int hurtx, int hurty, int hurtw, int hurth);
        void Render(int posx, int posy, SDL_RendererFlip flip, SDL_Renderer* gRenderer);
        int get_width();
        int get_height();
    protected:

    private:
        SDL_Rect* spriteClip;
        LTexture* spriteSheetTexture;
        int AnchorX;
        int AnchorY;
        SDL_Rect* hitBox;
        SDL_Rect* hurtBox;

};

#endif // SPRITE_H
